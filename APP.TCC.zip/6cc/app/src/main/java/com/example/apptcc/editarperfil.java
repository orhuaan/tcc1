package com.example.apptcc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class editarperfil extends AppCompatActivity {

    EditText editText;
    Button botao;

    private Text textview;
    private Button btn;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editarperfil);
        getSupportActionBar().hide();
        editText = (EditText) findViewById(R.id.edit_email);
        btn = (Button) findViewById(R.id.bt_pronto);
        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                enviarMSG();

            }
        });



        botao = findViewById(R.id.button_voltar1);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(editarperfil.this, formperfil.class);
                startActivity(intent);
            }
        });

    }

    public void enviarMSG()
    {
        AlertDialog.Builder msg = new AlertDialog.Builder(this);
        msg.setMessage("Parabéns "+"alterações feitas com sucesso!");
        msg.show();
    }

}