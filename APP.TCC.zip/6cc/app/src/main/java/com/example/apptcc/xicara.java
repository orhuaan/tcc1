package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class xicara extends AppCompatActivity {

   private Button botao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xicara);
        getSupportActionBar().hide();

        botao = findViewById(R.id.videoaulajava1);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=ebEhe5NBUw4&list=PLJ0AcghBBWSi6nK2CUkw9ngvwWB1gE8mL&index=3&ab_channel=TiagoAguiar")));
            }
        });


        botao = findViewById(R.id.videoaulajava2);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=-uwh4GWJBqc&list=PLJ0AcghBBWSi6nK2CUkw9ngvwWB1gE8mL&index=4&ab_channel=TiagoAguiar")));
            }
        });


        botao = findViewById(R.id.videoaulajava3);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=BLMu7ebMC1A&list=PLJ0AcghBBWSi6nK2CUkw9ngvwWB1gE8mL&index=6&ab_channel=TiagoAguiar")));
            }
        });




    }
}