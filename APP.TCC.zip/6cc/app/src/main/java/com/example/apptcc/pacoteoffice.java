package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class pacoteoffice extends AppCompatActivity {

    private Button botao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pacoteoffice);
        getSupportActionBar().hide();

        botao = findViewById(R.id.videoaulaoffice1);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=xQf53cj33PY&list=PLxNM4ef1Bpxj2_IG3rboXJBSCTxPlESBU&index=1&ab_channel=PortalHugoCursos")));
            }
        });

       botao = findViewById(R.id.videoaulaoffice2);

       botao.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=PuXDJ1i-6Gs&list=PLxNM4ef1Bpxj2_IG3rboXJBSCTxPlESBU&index=2&ab_channel=PortalHugoCursos")));
           }
       });

       botao = findViewById(R.id.videoaulaoffice3);

       botao.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=NPC6AROCq_M&list=PLxNM4ef1Bpxj2_IG3rboXJBSCTxPlESBU&index=3&ab_channel=PortalHugoCursos")));
           }
       });

    }







}