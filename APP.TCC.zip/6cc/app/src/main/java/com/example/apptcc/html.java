package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import org.w3c.dom.Text;

public class html extends AppCompatActivity {

    EditText editText;
    Button botao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_html);

        botao = findViewById(R.id.videoaulahtml1);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=iZ1ucWosOww&list=PLInBAd9OZCzydDFvm06EgbPXYylGVcyIL&index=1&ab_channel=RBtech")));
            }
        });

        botao = findViewById(R.id.videoaulahtml2);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=awabKnGTR1c&list=PLInBAd9OZCzydDFvm06EgbPXYylGVcyIL&index=2&ab_channel=RBtech")));
            }
        });

        botao = findViewById(R.id.videoaulahtml3);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity( new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=xgSSoUIr-Zg&list=PLInBAd9OZCzydDFvm06EgbPXYylGVcyIL&index=3&ab_channel=RBtech")));
            }
        });


    }
}