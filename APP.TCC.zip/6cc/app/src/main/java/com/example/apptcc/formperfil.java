package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

public class formperfil extends AppCompatActivity {

    private TextView textView;
    private Button botao;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_formperfil);

        botao = findViewById(R.id.button_voltar);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(formperfil.this, CategoriaActivity.class);
                startActivity(intent);
            }
        });
        botao = findViewById(R.id.button_editar);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(formperfil.this, editarperfil.class);
                startActivity(intent);
            }
        });
    }


}