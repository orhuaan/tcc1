package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CategoriaActivity extends AppCompatActivity {
    private TextView textView;
    private Button botao;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categorias);

        botao = findViewById(R.id.button_office);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CategoriaActivity.this,pacoteoffice.class);
                startActivity(intent);
            }
        });

        botao = findViewById(R.id.button_html);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CategoriaActivity.this,html.class);
                startActivity(intent);
            }
        });


        botao = findViewById(R.id.button_xicara);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CategoriaActivity.this,xicara.class);
                startActivity(intent);
            }
        });

        botao = findViewById(R.id.button_perfiil);
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CategoriaActivity.this,formperfil.class);
                startActivity(intent);
            }
        });




    }




}