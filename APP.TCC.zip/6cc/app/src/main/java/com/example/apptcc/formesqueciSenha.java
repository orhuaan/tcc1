package com.example.apptcc;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class formesqueciSenha extends AppCompatActivity {

    EditText editText;
    Button btn;
    View view;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formesqueci_senha);
        getSupportActionBar().hide();
        editText = (EditText) findViewById(R.id.edit_novasenha);
        btn = (Button) findViewById(R.id.bt_pronto);
        btn.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view) {
                enviarMSG();

            }
        });




    }

    public void enviarMSG()
    {
        AlertDialog.Builder msg = new AlertDialog.Builder(this);
        msg.setMessage("Foi enviado um link de confirmação no seu email!");
        msg.show();
    }

}