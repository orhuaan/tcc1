package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FormLogin extends AppCompatActivity {
    private TextView text_tela_esquecisenha;
    private Button botao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_login);

        getSupportActionBar().hide();
        IniciarComponentes();

        botao = findViewById(R.id.bt_entrar);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(FormLogin.this,CategoriaActivity.class);
                startActivity(intent);
            }
        });

        text_tela_esquecisenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(FormLogin.this,formesqueciSenha.class);
                startActivity(intent);
            }
        });
    }

    private void  IniciarComponentes(){
        text_tela_esquecisenha = findViewById(R.id.text_cadastrar_senha);

    }

}