package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class formperfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formperfil);
    }
}