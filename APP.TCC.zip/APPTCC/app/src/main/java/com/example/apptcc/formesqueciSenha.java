package com.example.apptcc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class formesqueciSenha extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formesqueci_senha);

        getSupportActionBar().hide();
    }
}